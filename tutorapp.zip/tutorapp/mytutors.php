<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href='http://fonts.googleapis.com/css?family=Arvo' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="statics/js/jquery-2.1.1.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Template</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="statics/stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <center><div style='width:100%;height:10px;top:30px;margin:0;padding:0;position:absolute;z-index:200000'><img src="statics/images/symbol.png"/ height='85' /></div></center>
	<div class="head">
    	<div>
        	<table >
              <tr>
                <td width="150" ><img src="statics/images/university_logo.png" alt="University" width="150" /></td>
                <td width="1" ><img src="statics/images/title_line.png" alt="|" width='150%'/></td>
                <td width="160" ><img src="../statics/images/tutor_logo.png"alt="Tutor's Bin" width="130"/></td>
              </tr>
            </table>
            <span style='position:absolute;top:10px;right:10%;text-align:right;'><h2>Log Out</h2></span>
        </div>

     </div>
     <div class="navbar">
     	<img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navclicked'>My Calendar</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navbutton'>My Tutors</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navbutton'>My Forum</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navbutton'>My Profile</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><input size='20 'style="position:absolute; right:4%;" id="mysearch" type="search"/> <img src="statics/images/searchicon.png" width="30px" style="position:absolute; right:1%;" />
     <div id='navline'></div>	 
     </div>
	</div>
    <div id="grayline"></div>
    <div class="grayside">
		<!-- InstanceBeginEditable name="GrayRegion" -->
        GrayRegion
		<!-- InstanceEndEditable -->
    </div>
    <div id='main'>
	<!-- InstanceBeginEditable name="MAINREGION" -->
    <style>
		table, th, td {
    		border: 1px solid black;
			border-collapse: collapse;
		}
		th,td {
    		padding: 15px;
		}
	</style>
    <table style="border:none;">
		<td>
		<table>
		<tr>
			<td>Basic Info goes here</td>
			<td>Availability goes here</td>
			<td>Current Classes tutoring for goes here</td>
		</tr>
		</table>
		</td>
		<td>
		<table style="border:none;">
			<td style="border:none;">Notes go here</td>
		</table>
		</tr></td>
	</table>

	<!-- InstanceEndEditable -->	
    </div>
<!-- /navbar -->
    
<div class='footer'>
	<center>
    	<img id='farrow' onclick='ftoggle();'style='margin:12px;'src="statics/images/uarrow.png" width="48" />
    </center>
    <table width="100%" border="0">
  <tr>
    <td height="140" ><div class="inputbox">
    	<div  id='notesbox'>Notes:</div> 
         <div  id='plusback'> <img src="../statics/images/plus.png"width="20"  /></div>
         <div  id='penback'> <img src="../statics/images/pen.png"width="20" /></div>
        <textarea name="comments" cols="58" rows="4" style=" background:none; border:none; margin-top:30px;"> </textarea>
       </div></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

    	<!-- InstanceBeginEditable name="FooterRegion" -->
		<!-- InstanceEndEditable --> 
</div>
</body>
<script type="text/javascript" src="statics/js/mocode.js"></script>
<!-- InstanceEnd --></html>
