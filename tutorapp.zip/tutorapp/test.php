<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/template.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href='http://fonts.googleapis.com/css?family=Arvo' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="statics/js/jquery-2.1.1.js"></script>

<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<!-- InstanceEndEditable -->
<link href="statics/stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <center><div style='width:100%;height:10px;top:30px;margin:0;padding:0;position:absolute;z-index:200000'><img src="statics/images/symbol.png"/ height='85' /></div></center>
	<div class="head">
    	<div>
        	<table >
              <tr>
                <td width="150" ><img src="statics/images/university_logo.png" alt="University" width="150" /></td>
                <td width="1" ><img src="statics/images/title_line.png" alt="|" width='150%'/></td>
                <td width="160" ><img src="../statics/images/tutor_logo.png"alt="Tutor's Bin" width="130"/></td>
              </tr>
            </table>
            <span style='position:absolute;top:10px;right:10%;text-align:right;'><h2>Log Out</h2></span>
        </div>

     </div>
     <div class="navbar">
     	<img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navclicked'>My Calendar</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navbutton'>My Tutors</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navbutton'>My Forum</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><span class='navbutton'>My Profile</span><img style='margin:-3px;margin-bottom:-20px;margin-top:-40px;padding-top:0px;z-index:100' src="statics/images/lbox.png" width="6" height="50" /><input size='20 'style="position:absolute; right:4%;" id="mysearch" type="search"/> <img src="statics/images/searchicon.png" width="30px" style="position:absolute; right:1%;" />
     <div id='navline'></div>	 
     </div>
	</div>
    <div id="grayline"></div>
    <div class="grayside">
		<!-- InstanceBeginEditable name="GrayRegion" -->
        GrayRegion
		<!-- InstanceEndEditable -->
    </div>
    <div id='main'>
	<!-- InstanceBeginEditable name="MAINREGION" -->
    MAINREGION
	<!-- InstanceEndEditable -->	
    </div>
<!-- /navbar -->
    
<div class='footer'>
	<center>
    	<img id='farrow' onclick='ftoggle();'style='margin:12px;'src="statics/images/uarrow.png" width="48" />
    <table width="90%" border="0">
  <tr>
    <td height="140" ><div class="inputbox">
    	<span id='notesbox'>Notes:</span> 
        <span id='penback'> <img src="../statics/images/pen.png"width="20" /></span>
        <span id='plusback'> <img src="../statics/images/plus.png"width="20"  /></span>
        <span>
        <textarea name="comments" cols="58" rows="4" style=" background:none; border-style:solid; margin-top:10px;"> </textarea></span>
       </div></td>
    <td>&nbsp;</td>
    <td align="right"><div class="inputbox">
    		<div  id='chatbox'>Chat:</div> 
        	<div id='addperson'><span><img style='margin-bottom:-6px;'src="../statics/images/plus.png"width="20"  /></span>  <span style='padding-left:30px;'><input type="text"></input></span></div>
        <div style=" z-index:2;background:none; border:none; margin-top:5px;margin-left:60px" readonly="readonly">
        	<span style='text-align:right;width:50px;display:inline-block;'>Me:</span><span style='text-align:left;margin-left:30px'>When's Our Meeting</span><br />
            <span style='text-align:right;width:50px;display:inline-block;'>Alex:</span><span style='text-align:left;margin-left:30px'>Tomorrow at 3:30 in Perkin's Lounge</span><br />
            <span style='text-align:right;width:50px;display:inline-block;'>Me:</span><span style='text-align:left;margin-left:30px'>Sound's great. See you then.</span><br />
            <span style='text-align:right;width:50px;display:inline-block;'>Me:</span><span style='text-align:left;margin-left:30px'>Where exactly are we meeting inside Perkin's?</span><br />
            <span style='display:inline-block;z-index:2;width:5px;height:85px;margin-left:60px;margin-top:-68px;border-right-style:dotted;border-color:#c3c3c3'></span>
		</div>
        <div id='bottomchat' style='vertical-align:middle; padding-bottom:10px;'><center><input type='text'></input> Send</center></div>
        </div>
        </td>
  </tr>
</table>
</center>
    	<!-- InstanceBeginEditable name="FooterRegion" --><!-- InstanceEndEditable --> 
</div>
</body>
<script type="text/javascript" src="statics/js/mocode.js"></script>
<!-- InstanceEnd --></html>
