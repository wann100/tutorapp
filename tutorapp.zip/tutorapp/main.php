<?php
    echo 'Hello world!';
?>
<html> 

<title>HTML with PHP</title> <body> <h1>My Example</h1> 
<center>
<img src="statics/logo.png"  width="60%"/>
</center></body>
</html>