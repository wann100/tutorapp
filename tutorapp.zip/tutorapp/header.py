import cgi
import urllib
import webapp2
import jinja2
import os
import hashlib
import random
import time
import exceptions
import json
import update_schema
import urlparse
import string
import logging
from google.appengine.ext import deferred
from datetime import datetime, timedelta

from google.appengine.api import users
from google.appengine.api import mail
from google.appengine.api import urlfetch
from google.appengine.ext import ndb
from google.appengine.ext import blobstore
from google.appengine.ext.webapp import blobstore_handlers
